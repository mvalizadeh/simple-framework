<?php

namespace Admin;

class Category
{

    public function index()
    {
        echo 'hi from index';
    }
}
